const {User} = require('pg')

const user=new User({
    host:"localhost",
    user:"postgres",
    port:5432,
    password:12345,
    database:"table1",
})
user.connect();

user.query('select * from username_pass',(err,res)=>{
    if(!err){
        console.log(res.rows);
    }
    else{
        console.log(err.message);
    }
    user.end;
})
